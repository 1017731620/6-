$(document).ready(function () {
var index=0;
$("#right").click(throttle(fnright,800));
 $("#left").click(throttle(fnleft,800));
function fnright(){
    if(index > 3){
        index=0;
        carousel(0,1000);
    }
    index++;
    var site = -index * $(".seckill_SS").width();
    carousel(site,1000);
}
function fnleft(){
    if(index == 0){
        index=4;
        var site = -index * $(".seckill_SS").width();
     carousel(site,1000);
    }
        index--;
    var site = -index * $(".seckill_SS").width();
     carousel(site,1000);
}

function carousel(site,time){
    $(".SS_ul").stop([true],[true]).animate({
        "left": site
    }, time);
}

function throttle(fn, time) {
    //设置一个初始值
    var beforeTime = 0;
    //返回一个函数
    return function () {
        //保存this和arguments类数组
        var self = this;
        var args = arguments;
        //获取现在的时间戳
        var currTime = +new Date();
        //如果现在时间戳的值减去初始时间戳的值大于设置的time（1000）则执行函数，否则不执行
        if (currTime - beforeTime >= time) {
            //执行函数，apply改变指向为self
            fn.apply(self, args);
            //将现在的时间戳赋给初始值
            beforeTime = currTime;
        }
    }
}
});