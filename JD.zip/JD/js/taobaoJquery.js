$(document).ready(function () {
    var index = 0;
    var set = null;
    carousel();
    as();
    // 点击向右节流 0.8秒一次
    $("#right").click(throttle(fnright,800));
     // 点击向左节流 0.8秒一次
    $("#left").click(throttle(fnleft,800));
     // 点击下方a标签节流 0.6秒一次
    $(".item a").click(throttle(nava,600));
    function fnright() {
        clearInterval(set);
        if (index ==  $("li").length - 1) {
            index = 0;
            $(".list").css("left", 0);
        }
        index++;
        var site = -index * parseInt($("li").css("width")) + "px";
        move(site, 700)
        carousel();
    }

    function fnleft() {
        //点击切换图片
        clearInterval(set);
        if (index == 0) {
            index = $("li").length - 1;
           $(".list").css("left", -index * parseInt($("li").css("width")) + "px");
        }
        index--;
        var site = -index * parseInt($("li").css("width")) + "px";
        move(site, 700)
        carousel();
    }
    function carousel() {
        set = setInterval(function () {
            //如果索引等ul下li的总长度-1张时让index重新等于1
            if (index == $("li").length - 1) {
                index = 0;
                $(".list").css("left", 0);
            }
            //每次定时让索引自增        
            index++;
            //创建一个变量保存ul要移动的距离等于索引值乘以每个li元素的宽度
            var site = -index * parseInt($("li").css("width")) + "px";
            move(site, 700)
        }, 3000);
    };


    function nava() {
            var newindex = $(this).index();
            clearInterval(set);
            index = newindex;
            as();
            var site = -index * parseInt($("li").css("width")) + "px";
            move(site, 700);
            carousel();
    }

    function as() {
        if (index == $("li").length - 1) {
            $(".item a").eq(0).addClass("red").siblings().removeClass("red");
        } else {
            $(".item a").eq(index).addClass("red").siblings().removeClass("red");
        }
    }

    function move(site, time) {
        $(".list").stop([true],[true]).animate({
            "left": site
        }, time);
        as();
    }

    function throttle(fn, time) {
        //设置一个初始值
        var beforeTime = 0;
        //返回一个函数
        return function () {
            //保存this和arguments类数组
            var self = this;
            var args = arguments;
            //获取现在的时间戳
            var currTime = +new Date();
            //如果现在时间戳的值减去初始时间戳的值大于设置的time（1000）则执行函数，否则不执行
            if (currTime - beforeTime >= time) {
                //执行函数，apply改变指向为self
                fn.apply(self, args);
                //将现在的时间戳赋给初始值
                beforeTime = currTime;
            }
        }
    }

});