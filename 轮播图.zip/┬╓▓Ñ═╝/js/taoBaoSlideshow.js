window.onload = function () {
    //创建一个索引
    var index = 0;
    //创建一个变量保存定时器
    var set = null;
    var aul = document.getElementsByClassName("list")[0];
    var lis = aul.getElementsByTagName("li");
    var item = document.getElementsByClassName("item")[0].getElementsByTagName("a");
    var left = document.getElementById("left");
    var right = document.getElementById("right");

    //  通过getComputedStyle获取li标签的宽度
    var liWidth = parseInt(getComputedStyle(lis[0], null).width);
    carousel();
    nava();

    function carousel() {


        set = setInterval(function () {
            //如果索引等ul下li的总长度-1张时让index重新等于1
            if (index == lis.length - 1) {
                index = 0;
                aul.style.left = 0;
            }
            //每次定时让索引自增        
            index++;
            //创建一个变量保存ul要移动的距离等于索引值乘以每个li元素的宽度
            var site = index * liWidth
            //调用函数执行动画
            move(aul, "left", -site, 20);
        }, 2500);

    };




    function fnright() {
        clearInterval(set);
        if (index == lis.length - 1) {
            index = 0;
            aul.style.left = 0;
        }
        index++;
        var site = index * liWidth;
        move(aul, "left", -site, 20);
        carousel();
    }

    function fnleft() {
        //点击切换图片
        clearInterval(set);

        if (index == 0) {
            index = lis.length - 1;
            aul.style.left = -index * liWidth + "px";
        }
        index--;
        var site = index * liWidth;
        move(aul, "left", -site, 20);
        carousel();
    }

    //点击切换图片
    function nava() {
        for (let i = 0; i < item.length; i++) {

            item[i].classList.remove("red");
            if (index == lis.length - 1) {
                item[0].classList.add("red");
            } else {
                item[index].classList.add("red");
            }
            item[i].addEventListener("click", function (event) {
                clearInterval(set);
                index = i;
                var site = index * liWidth
                //调用函数执行动画
                move(aul, "left", -site, 100);
                carousel();
            }, false)
        }

    }
    //轮播动画
    function move(obj, attr, target, speed) {

        //关闭上一个定时器
        clearInterval(obj.timer);

        //获取元素目前的位置
        var current = parseInt(getComputedStyle(obj, null)[attr]);
        //判断速度的正负值
        if (current > target) {
            //此时速度应为负值
            speed = -speed;
        }

        //开启一个定时器，用来执行动画效果
        //向执行动画的对象中添加一个timer属性，用来保存它自己的定时器的标识
        obj.timer = setInterval(function () {

            //获取box1的原来的left值
            var oldValue = parseInt(getComputedStyle(obj, null)[attr]);

            //在旧值的基础上增加
            var newValue = oldValue + speed;

            if ((speed < 0 && newValue < target) || (speed > 0 && newValue > target)) {
                newValue = target;
            }
            console.log(current);
            //将新值设置给box1
            obj.style.left = newValue + "px";

            //当元素移动到0px时，使其停止执行动画
            if (newValue == target) {
                //达到目标，关闭定时器
                clearInterval(obj.timer);

                nava();
            }

        }, 15);
    }

    left.onclick = throttle(fnleft, 600);
    right.onclick = throttle(fnright, 600);



    //节流
    function throttle(fn, time) {
        //设置一个初始值
        var beforeTime = 0;
        //返回一个函数
        return function () {
            //保存this和arguments类数组
            var self = this;
            var args = arguments;
            //获取现在的时间戳
            var currTime = +new Date();
            //如果现在时间戳的值减去初始时间戳的值大于设置的time（1000）则执行函数，否则不执行
            if (currTime - beforeTime >= time) {
                //执行函数，apply改变指向为self
                fn();
                //将现在的时间戳赋给初始值
                beforeTime = currTime;
            }
        }
    }

}