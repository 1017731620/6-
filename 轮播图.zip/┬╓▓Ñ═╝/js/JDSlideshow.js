window.onload=function(){

    
    var index=0;
    var set=null;
    var lis=document.querySelectorAll(".list li");
    var left = document.getElementById("left");
    var right = document.getElementById("right");
    var item =document.querySelectorAll(".item a");
    carousel();
    nav();
    left.onclick = throttle(fnleft, 500);
    right.onclick = throttle(fnright, 500);
 // 点击向右切换图片
    function fnright() {
        
        if (index == lis.length-1) {
            index = 0;
            del() ; 
        }else{
            index++;
            del();   
        }
        
    }
//点击向左切换图片
    function fnleft() {    
        if (index == 0) {  
            index = lis.length-1;
            del() ; 
        }else{
            index--;
            del() ;
        }     
    }

    

    
    function nav(){
        for(let i=0; i<item.length;i++){
            item[i].classList.remove("red");
            if (index > lis.length) {
                item[0].classList.add("red");
            } else {
                item[index].classList.add("red");
            }
            item[i].onclick=function(){
                index = i;
                  del();
            }
        }
    }
    
    //自动轮播图片
    function carousel(){
      
        clearInterval(set);
        set = setInterval(function(){  
            
            index++; 
            if(index > lis.length-1){
                index = 0;
            } 
            // alert(index);
            del();
           
        },2500)
    }
   
//淡入淡出
    function del(){
        for(var i =0;i<lis.length;i++){
            lis[i].className="lis";
        }
        lis[index].className="newli";
        carousel();
        nav();
        
    }
    

   


    //节流
    function throttle(fn, time) {
        //设置一个初始值
        var beforeTime = 0;
        //返回一个函数
        return function () {
            //保存this和arguments类数组
            var self = this;
            var args = arguments;
            //获取现在的时间戳
            var currTime = +new Date();
            //如果现在时间戳的值减去初始时间戳的值大于设置的time（1000）则执行函数，否则不执行
            if (currTime - beforeTime >= time) {
                //执行函数，apply改变指向为self
                fn();
                //将现在的时间戳赋给初始值
                beforeTime = currTime;
            }
        }
    }

}










